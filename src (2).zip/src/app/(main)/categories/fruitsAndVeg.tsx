// src/app/(main)/categoria/[nombre].tsx

import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';

import BottomTabBar from '../../components/BottomTabBar';
import Header from '../../components/Header';

// ----------------------------------------------------------------
// Si tienes datos reales por categoría, podrías importarlos o traerlos
// con fetch/axios dentro de useEffect. Aquí voy a simular con datos
// estáticos: un array de “productos” para cada categoría.
// ----------------------------------------------------------------
const productosPorCategoria: Record<string, { id: string; name: string; image: any }[]> =
  {
    'Fruits and Vegetables': [
      { id: '1', name: 'Apple', image: require('../../assets/images/fruits.png') },
      { id: '2', name: 'Banana', image: require('../../assets/images/fruits.png') },
      { id: '3', name: 'Carrot', image: require('../../assets/images/fruits.png') },
    ],
    'Dairy and Cereals': [
      { id: '4', name: 'Milk', image: require('../../assets/images/dairy.png') },
      { id: '5', name: 'Cheese', image: require('../../assets/images/dairy.png') },
    ],
    Beverages: [
      { id: '6', name: 'Water Bottle', image: require('../../assets/images/beverages.png') },
      { id: '7', name: 'Soda', image: require('../../assets/images/beverages.png') },
    ],
    Snacks: [
      { id: '8', name: 'Doritos', image: require('../../assets/images/snacks.png') },
      { id: '9', name: 'Lays', image: require('../../assets/images/snacks.png') },
    ],
    Meat: [
      { id: '10', name: 'Chicken Breast', image: require('../../assets/images/meat.png') },
      { id: '11', name: 'Beef Steak', image: require('../../assets/images/meat.png') },
    ],
    'Cleaning Supplies': [
      { id: '12', name: 'Detergent', image: require('../../assets/images/cleaning.png') },
      { id: '13', name: 'Bleach', image: require('../../assets/images/cleaning.png') },
    ],
  };

const CARD_MARGIN = 10;
const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 60) / 2;
const CARD_HEIGHT = 160;

export default function CategoriaScreen() {
  // 1) Recuperamos el parámetro “nombre” de la URL dinámica
  //    Por ejemplo: /categoria/Fruits%20and%20Vegetables
  const { nombre } = useLocalSearchParams<{ nombre: string }>();

  // 2) Para el tab bar:
  const [activeTab, setActiveTab] = useState('home');
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const TAB_BAR_HEIGHT = 60;

  // 3) Estado local para los productos de esta categoría
  const [productos, setProductos] = useState<
    { id: string; name: string; image: any }[]
  >([]);

  useEffect(() => {
    // Simulamos “cargar” los productos según la categoría. 
    // En un caso real podrías hacer fetch a tu backend.
    if (nombre && productosPorCategoria[nombre]) {
      setProductos(productosPorCategoria[nombre]);
    } else {
      setProductos([]);
    }
  }, [nombre]);

  // 4) Función para manejar la navegación desde el tab bar
  const handleTabPress = (tab: string) => {
    setActiveTab(tab);
    switch (tab) {
      case 'home':
        router.push('/(main)/home');
        break;
      case 'favorites':
        router.push('/(main)/favorites');
        break;
      case 'scan':
        router.push('/(main)/scan');
        break;
      case 'cart':
        router.push('/(main)/cart');
        break;
      case 'more':
        router.push('/(main)/more');
        break;
    }
  };

  // 5) Función para renderizar cada “ficha de producto” dentro de esta categoría
  const renderProducto = ({
    item,
  }: {
    item: { id: string; name: string; image: any };
  }) => {
    return (
      <TouchableOpacity style={styles.productoCard} onPress={() => {
        // Si quisieras navegar a otra subficha de producto, lo harías aquí.
        // Ej: router.push(`/producto/${item.id}`)
      }}>
        <Image source={item.image} style={styles.productoImage} resizeMode="contain" />
        <Text style={styles.productoTitle}>{item.name}</Text>
      </TouchableOpacity>
    );
  };

  return (
    // 1) Root: View normal, para que BottomTabBar quede absolute al bottom real
    <View style={styles.root}>
      {/* 
        2) Header: dentro de SafeAreaView para respetar zona superior (notch/status bar)
      */}
      <SafeAreaView edges={['top']} style={styles.headerSafeArea}>
        <Header location="Sarmiento 123" onPressLocation={() => {}} />
      </SafeAreaView>

      {/* 
        3) Título de la categoría: 
           Mostramos “Ficha de <nombre>” o cualquier título que prefieras.
      */}
      <View style={styles.tituloWrapper}>
        <Text style={styles.tituloCategoria}>{nombre}</Text>
      </View>

      {/*
        4) Lista de productos de esta categoría:
           — Si no hay productos, mostramos un texto “No hay productos”.
           — Si existen, un FlatList bidimensional para mostrar tarjetas.
      */}
      {productos.length === 0 ? (
        <View style={styles.sinProductosWrapper}>
          <Text style={styles.sinProductosText}>
            No hay productos para "{nombre}"
          </Text>
        </View>
      ) : (
        <FlatList
          data={productos}
          numColumns={2}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{
            paddingHorizontal: 10,
            paddingBottom: TAB_BAR_HEIGHT + insets.bottom,
            paddingTop: 10,
          }}
          columnWrapperStyle={styles.rowWrapper}
          renderItem={renderProducto}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/*
        5) BottomTabBar absoluted al fondo real:
           — Sin SafeAreaView que lo contenga, para que quede pegado.
           — Internamente BottomTabBar usa insets.bottom para saber
             cuánto padding dejarle al home indicator.
      */}
      <BottomTabBar activeTab={activeTab} onTabPress={handleTabPress} />
    </View>
  );
}

// Importar Dimensions aquí para calcular CARD_WIDTH
import { Dimensions } from 'react-native';

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: 'white',
  },
  headerSafeArea: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 6,
    zIndex: 10,
  },
  tituloWrapper: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: 'white',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#ddd',
  },
  tituloCategoria: {
    fontSize: 22,
    fontWeight: '700',
  },
  sinProductosWrapper: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sinProductosText: {
    fontSize: 16,
    color: '#555',
    fontStyle: 'italic',
  },
  rowWrapper: {
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  productoCard: {
    width: CARD_WIDTH,
    height: CARD_HEIGHT,
    backgroundColor: 'white',
    borderRadius: 15,
    marginHorizontal: CARD_MARGIN / 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  productoImage: {
    width: 80,
    height: 80,
    marginBottom: 8,
  },
  productoTitle: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
});
