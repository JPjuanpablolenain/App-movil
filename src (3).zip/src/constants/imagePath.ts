export default {
    logo: require("@/src/assets/images/icon.png"),
}